/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['verbwire-stream-react'],
};
 
module.exports = nextConfig;

